# secret key for signing cookies
SECRET_KEY = "something wicked this way comes - Echo"

# MySQL configurations
MYSQL_DATABASE_USER = 'root'
MYSQL_DATABASE_PASSWORD = 'test'
MYSQL_DATABASE_DB = 'BirdApp'
MYSQL_DATABASE_HOST = 'localhost'


# file upload configurations
UPLOAD_FOLDER = 'static/Uploads'
